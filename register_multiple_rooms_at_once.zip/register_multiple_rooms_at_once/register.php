<?php

$connect = mysqli_connect('localhost', 'root', '', 'test');


    if (isset($_POST['submit'])) {
    	
    	$d = $_POST['room'];

    	echo '
        <head>
        <link rel="stylesheet" href="bootstrap.css">
        <style>
        #div {
			margin-top: 140px;
		}
		form {
			margin-top: 140px;
		}
	    </style>
        </head>
        <body>

	    <div class="container" id="div">
		    <div class="col-md-9">
			    <div class="card mt-7">
				    <div class="card-header">
					<h3>Register Booked Rooms</h3>
				    </div>
				    <div class="card-body">
    ';
        echo "<form method='POST' action='' class='container'>";

    	for ($i=1; $i <= $d; $i++) { 
    		
    		echo "<input type='hidden' name='rooms[]' value='Room ".$i."'>";
    	}

        echo "<p>Rooms have been submitted successfully. Press the bellow button to Register them.</p>";
    	echo '
        <p><input type="submit" name="result" class="btn btn-primary" value="Register Rooms"></p></form>
                    </div>
                    <div class="card-footer">
					    <a href="./" class="alert-link text-decoration-none">Home</a>&nbsp;|&nbsp;
					    <a href="select.php" class="alert-link text-decoration-none">Register Users</a>&nbsp;|&nbsp;
					    <a href="display-rooms.php" class="alert-link text-decoration-none">Show Registered</a>&nbsp;|&nbsp;
					    <a href="#" class="alert-link text-decoration-none">Privacy Policy</a>&nbsp;&nbsp;
				    </div>
                </div>
            </div>
        </div>
        ';
    }

    if (isset($_POST['result'])) {

    	$give = $_POST['rooms'];

    foreach ($give as $given) {
    	
    	//echo "Rooms: " .$given. "<br>";

    $select = "SELECT * FROM rooms WHERE roomname = '$given'";
    $selectresult = mysqli_query($connect, $select);

    if (mysqli_num_rows($selectresult) == 0) {
    	
    	$sql = "INSERT INTO rooms(roomname) VALUES('$given')";
        $result = mysqli_query($connect, $sql);

    } else {
        echo "<script>alert('Room(s) registered!'); location.replace('./');</script>";
    }
    
    }

    if ($result) {
    	
    	echo "<script>alert('Registration Successful'); location.replace('./');</script>";

    } else {
    	echo "Try again later!";
    }
    }
?>
