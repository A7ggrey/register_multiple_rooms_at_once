<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Display</title>
	<link rel="stylesheet" href="bootstrap.css">
	<style>
		#div {
			margin-top: 140px;
		}
		form {
			margin-top: 100px;
		}
	</style>
</head>
<body>

	<div class="container" id="div">
		<div class="col-md-8">
			<div class="card mt-5">
				<div class="card-header">
					<h3>Enter the Number of Rooms</h3>
				</div>
				<div class="card-body">
				<form method="POST" action="register.php" class="container">
		<p>Room Number of Last Rooms you want to register:</p>
		<p><input type="number" min="1" name="room" class="form-control" required></p>
		<div class="form-group mb-3">
		<input type="submit" name="submit" class="btn btn-success" value="submit">
		</div>
	</form>
				</div>
				<div class="card-footer">
					<a href="./" class="alert-link text-decoration-none">Home</a>&nbsp;|&nbsp;
					<a href="select.php" class="alert-link text-decoration-none">Register Users</a>&nbsp;|&nbsp;
					<a href="display-rooms.php" class="alert-link text-decoration-none">Show Registered</a>&nbsp;|&nbsp;
					<a href="#" class="alert-link text-decoration-none">Privacy Policy</a>&nbsp;&nbsp;
				</div>
			</div>
		</div>
	</div>

</body>
</html>