<?php

$connect = mysqli_connect('localhost', 'root', '', 'test');

if (isset($_POST['submit'])) {
	
	$room = $_POST['room'];
	$name = mysqli_real_escape_string($connect, $_POST['name']);

	$query1 = "SELECT * FROM user WHERE room = '$room'";
	$result1 = mysqli_query($connect, $query1);

	if (mysqli_num_rows($result1) > 0) {
		
		echo "Room already occupied!";
	} else {

	$query = "INSERT INTO user(name, room) VALUES('$name', '$room')";
	$result = mysqli_query($connect, $query);

	if ($result) {
		
		echo "<script>alert('User registered successfully!'); location.replace('./select.php');</script>";
	} else {
		echo "Something went wrong!";
	}
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Select Rooms</title>
	<link rel="stylesheet" href="bootstrap.css">
	<style>
		#div {
			margin-top: 140px;
		}
		form {
			margin-top: 100px;
		}
	</style>
</head>
<body>

	<div class="container" id="div">
		<div class="col-md-8">
			<div class="card mt-5">
				<div class="card-header">
					<h3>Enter the Number of Rooms</h3>
				</div>
				<div class="card-body">
				</head>


	<form method="POST" action="" onsubmit="return validate()">
		<p>Select a room:</p>
		<p>
			<select name="room" class="form-control" id="sel">
		       <option value="0">-- Select a room --</option>
		<?php

		    $select = "SELECT * FROM rooms ORDER BY roomid ASC";
		    $result = mysqli_query($connect, $select);
		    while ($rows = mysqli_fetch_assoc($result)) {

		    	?>
		    	
		       <option value="<?php echo $rows['roomid']?>"><?php echo $rows['roomname']?></option>

		    <?php
		    }
		?>
	         </select>
	    </p>
	    <p>Client Name:</p>
	    <p>
	    	<input type="text" name="name" placeholder="Your Name" id="nam" class="form-control">
	    </p>

	    <p>
	    	<input type="submit" name="submit" class="btn btn-success" value="Register User">
	    </p>
	</form>
				</div>
				<div class="card-footer">
				    <a href="./" class="alert-link text-decoration-none">Home</a>&nbsp;|&nbsp;
					<a href="select.php" class="alert-link text-decoration-none">Register Users</a>&nbsp;|&nbsp;
					<a href="display-rooms.php" class="alert-link text-decoration-none">Show Registered</a>&nbsp;|&nbsp;
					<a href="#" class="alert-link text-decoration-none">Privacy Policy</a>&nbsp;&nbsp;
				</div>
			</div>
		</div>
	</div>

</body>

<script>
	function validate() {
		var s = document.getElementById('sel').value;
		var n = document.getElementById('nam').value;

		if (s == 0 || s == null) {
			alert('Please Select a room!');
			return false;
		}

		if (n == 0 || n == null) {
			alert('Please Fill in your name!');
			return false;
		}
	}
</script>
</html>