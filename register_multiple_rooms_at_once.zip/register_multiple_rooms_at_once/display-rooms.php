<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Display rooms</title>
	<link rel="stylesheet" href="bootstrap.css">
	<style>
		#div {
			margin-top: 140px;
		}
		form {
			margin-top: 100px;
		}
	</style>
</head>
<body>

	<div class="container" id="div">
		<div class="col-md-9">
			<div class="card mt-7">
				<div class="card-header">
					<h3>Booked Rooms</h3>
				</div>
				<div class="card-body">
				<table class="table table-striped">
		<thead>
		<tr>
			<th>Name</th>
			<th>Room</th>
		</tr>
		</thead>
		<tbody>
		<?php
		    $connect = mysqli_connect('localhost', 'root', '', 'test');

		    $query = "SELECT rooms.*, user.* FROM rooms INNER JOIN user ON rooms.roomid = user.room ORDER BY rooms.roomid ASC";
		    $result = mysqli_query($connect, $query);

		    while ($rows = mysqli_fetch_assoc($result)) {
		    	?>

		    	<tr>
		    		<td><?php echo $rows['name'];?></td>
		    		<td><?php echo $rows['roomname'];?></td>
		    	</tr>

		    	<?php
		    }

		?>
		</tbody>
	</table>
				</div>
				<div class="card-footer">
				    <a href="./" class="alert-link text-decoration-none">Home</a>&nbsp;|&nbsp;
				    <a href="select.php" class="alert-link text-decoration-none">Register Users</a>&nbsp;|&nbsp;
					<a href="display-rooms.php" class="alert-link text-decoration-none">Show Registered</a>&nbsp;|&nbsp;
					<a href="#" class="alert-link text-decoration-none">Privacy Policy</a>&nbsp;&nbsp;
				</div>
			</div>
		</div>
	</div>

</body>
</html>
	

</body>
</html>